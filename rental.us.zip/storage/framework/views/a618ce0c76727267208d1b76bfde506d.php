<footer class="footer mt-auto py-3 bg-white text-center">
    <div class="container">
        <span class="text-muted"> Copyright © <span id="year">2024</span> <a href="javascript:void(0);"
                class="text-dark fw-semibold"><?php echo e(env('APP_NAME')); ?></a> All Rights Reserved -
            Developed By <a target="_blank" href="https://prodevsltd.com">
                <span class="fw-semibold text-primary">Pro Devs</span>
            </a>
        </span>
    </div>
</footer>
<?php /**PATH D:\xampp\htdocs\rental.us\resources\views/backEnd/admin/includes/footer.blade.php ENDPATH**/ ?>