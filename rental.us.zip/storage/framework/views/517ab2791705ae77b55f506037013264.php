<?php if (isset($component)) { $__componentOriginal292c42cda3271405dc664835e31595e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal292c42cda3271405dc664835e31595e3 = $attributes; } ?>
<?php $component = App\View\Components\FrontendLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <!-- ============================ Page Title Start================================== -->
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">

                    <h2 class="ipt-title">About Us</h2>
                    <span class="ipn-subtitle">Who we are & our mission</span>

                </div>
            </div>
        </div>
    </div>
    <!-- ============================ Page Title End ================================== -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ============================ Our Story Start ================================== -->
    <section>
        <div class="container">
            <?php
                $story = \App\Models\Story::where('status', 'active')->first();
            ?>

            <?php if($story): ?>
            <!-- row Start -->
            <div class="row align-items-center">

                <div class="col-lg-6 col-md-6">
                    <img src="<?php echo e(asset($story->image ?: 'frontEnd/img/sb.png')); ?>" class="img-fluid" alt="Our Story" />
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="story-wrap explore-content">

                        <h2><?php echo e($story->title); ?></h2>
                        <p><?php echo e($story->content); ?></p>

                        <?php if($story->content_second): ?>
                        <p><?php echo e($story->content_second); ?></p>
                        <?php endif; ?>

                    </div>
                </div>

            </div>
            <!-- /row -->
            <?php else: ?>
            <div class="row align-items-center">
                <div class="col-12 text-center">
                    <p>Our story content is coming soon...</p>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </section>
    <!-- ============================ Our Story End ================================== -->

    <!-- ================= Our Team================= -->
    <section class="gray-bg">
        <div class="container">
            <?php
                $teams = \App\Models\Team::active()->ordered()->get();
            ?>

            <?php if($teams->count() > 0): ?>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="sec-heading center">
                        <h2>Meet Our Team</h2>
                        <p>Professional & Dedicated Team</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="team-slide item-slide">
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Single Team Member -->
                        <div class="single-team">
                            <div class="team-grid">
                                <div class="teamgrid-user">
                                    <img src="<?php echo e(asset($team->image ?: 'frontEnd/img/team-placeholder.jpg')); ?>" alt="<?php echo e($team->name); ?>" class="img-fluid" />
                                </div>

                                <div class="teamgrid-content">
                                    <h4><?php echo e($team->name); ?></h4>
                                    <span><?php echo e($team->position); ?></span>
                                    
                                </div>

                                <div class="teamgrid-social">
                                    <ul>
                                        <?php if($team->facebook): ?>
                                        <li><a href="<?php echo e($team->facebook); ?>" target="_blank" class="f-cl"><i class="fa-brands fa-facebook"></i></a></li>
                                        <?php endif; ?>
                                        <?php if($team->twitter): ?>
                                        <li><a href="<?php echo e($team->twitter); ?>" target="_blank" class="t-cl"><i class="fa-brands fa-twitter"></i></a></li>
                                        <?php endif; ?>
                                        <?php if($team->instagram): ?>
                                        <li><a href="<?php echo e($team->instagram); ?>" target="_blank" class="i-cl"><i class="fa-brands fa-instagram"></i></a></li>
                                        <?php endif; ?>
                                        <?php if($team->linkedin): ?>
                                        <li><a href="<?php echo e($team->linkedin); ?>" target="_blank" class="l-cl"><i class="fa-brands fa-linkedin"></i></a></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="row">
                <div class="col-12 text-center">
                    <p class="text-muted">Team members is coming soon...</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <!-- =============================== Our Team ================================== -->

    <!-- ================= Our Mission ================= -->
    <section>
        <div class="container">
            <?php
                $mission = \App\Models\Mission::getActive();
            ?>

            <?php if($mission): ?>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="sec-heading center">
                        <h2>Our Mission & Work Process</h2>
                        <p>Professional & Dedicated Team</p>
                    </div>
                </div>
            </div>

            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6">
                    <?php $__currentLoopData = $mission->mission_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['status'] == 'active'): ?>
                        <div class="icon-mi-left">
                            <i class="<?php echo e($item['icon_class']); ?> text-main"></i>
                            <div class="icon-mi-left-content">
                                <h4><?php echo e($item['title']); ?></h4>
                                <p><?php echo e($item['description']); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-lg-6 col-md-6">
                    <img src="<?php echo e(asset($mission->image_path)); ?>" class="img-fluid" alt="Our Mission" />
                </div>
            </div>
            <?php else: ?>
            <div class="row">
                <div class="col-12 text-center">
                    <p class="text-muted">Mission content is coming soon...</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <!-- ================= Our Mission ================= -->
<?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal292c42cda3271405dc664835e31595e3)): ?>
<?php $attributes = $__attributesOriginal292c42cda3271405dc664835e31595e3; ?>
<?php unset($__attributesOriginal292c42cda3271405dc664835e31595e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal292c42cda3271405dc664835e31595e3)): ?>
<?php $component = $__componentOriginal292c42cda3271405dc664835e31595e3; ?>
<?php unset($__componentOriginal292c42cda3271405dc664835e31595e3); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\rental.us\resources\views/frontEnd/pages/about-us.blade.php ENDPATH**/ ?>