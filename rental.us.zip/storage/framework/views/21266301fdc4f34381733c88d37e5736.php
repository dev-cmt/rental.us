<?php if (isset($component)) { $__componentOriginal292c42cda3271405dc664835e31595e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal292c42cda3271405dc664835e31595e3 = $attributes; } ?>
<?php $component = App\View\Components\FrontendLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <!-- ============================ Hero Banner  Start================================== -->
    <div class="light-bg hero-banner">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12">
                    <div class="d-flex align-items-center justify-content-start mb-2">
                        <div
                            class="label rounded-pill bg-white text-dark d-flex align-items-center justify-content-center px-2 py-2 pe-3">
                            <span class="label bg-green rounded-pill text-uppercase me-2">New</span>Get 20% Off with
                            Super Agent
                        </div>
                    </div>
                    <h2>Find Your Dream House<br>In <span class="element" data-elements="California, Denver, Las Vegas, San Antonio, San Francisco, Los Angeles, New Orleans, San Diego"></span>
                    </h2>
                    <p class="small">Find homes in 80+ different countries represented byb 700 leading member brokerages.</p>
                    <div class="full-search-2 eclip-search italian-search hero-search-radius mt-5">
                        <div class="hero-search-content">
                            <div class="row">

                                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 b-r">
                                    <div class="form-group">
                                        <div class="choose-propert-type">
                                            <ul>
                                                <li>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" id="typbuy"
                                                            name="typeprt">
                                                        <label class="form-check-label" for="typbuy">
                                                            Buy
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" id="typrent"
                                                            name="typeprt" checked>
                                                        <label class="form-check-label" for="typrent">
                                                            Rent
                                                        </label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xl-7 col-lg-6 col-md-5 col-sm-12 px-xl-0 px-lg-0 px-md-0">
                                    <div class="form-group border-start borders">
                                        <div class="position-relative">
                                            <input type="text" class="form-control border-0 ps-5"
                                                placeholder="Search for a location">
                                            <div class="position-absolute top-50 start-0 translate-middle-y ms-2">
                                                <span class="svg-icon text-main svg-icon-2hx">
                                                    <svg width="25" height="25" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path opacity="0.3"
                                                            d="M18.0624 15.3453L13.1624 20.7453C12.5624 21.4453 11.5624 21.4453 10.9624 20.7453L6.06242 15.3453C4.56242 13.6453 3.76242 11.4453 4.06242 8.94534C4.56242 5.34534 7.46242 2.44534 11.0624 2.04534C15.8624 1.54534 19.9624 5.24534 19.9624 9.94534C20.0624 12.0453 19.2624 13.9453 18.0624 15.3453Z"
                                                            fill="currentColor" />
                                                        <path
                                                            d="M12.0624 13.0453C13.7193 13.0453 15.0624 11.7022 15.0624 10.0453C15.0624 8.38849 13.7193 7.04535 12.0624 7.04535C10.4056 7.04535 9.06241 8.38849 9.06241 10.0453C9.06241 11.7022 10.4056 13.0453 12.0624 13.0453Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xl-2 col-lg-3 col-md-3 col-sm-12">
                                    <div class="form-group">
                                        <button type="button" class="btn btn-dark full-width">Search</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="searches-lists">
                        <ul>
                            <li><span>Popular Searches:</span></li>
                            <li><a href="JavaScript:Void(0);">2 BHK</a></li>
                            <li><a href="JavaScript:Void(0);" class="active">Banglaw</a></li>
                            <li><a href="JavaScript:Void(0);">Apartment</a></li>
                            <li><a href="JavaScript:Void(0);">London</a></li>
                            <li><a href="JavaScript:Void(0);">Villa</a></li>
                        </ul>
                    </div>

                </div>
                <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12">
                    <div class="">
                        <img src="<?php echo e(asset('frontEnd')); ?>/img/side-city-1.png" class="img-fluid" alt="" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================ Hero Banner End ================================== -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ============================ Category Start ================================== -->
    <section>
        <div class="container">

            <div class="row">
                <div class="col-lg-7 col-md-10">
                    <div class="sec-heading mb-4 mss">
                        <h2>Choose Property Type</h2>
                        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                            voluptatum deleniti atque corrupti quos dolores</p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center gx-3 gy-3">
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-house-laptop"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Commercial</h4>
                                <p>12 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-building"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Apartment</h4>
                                <p>16 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-building-shield"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Townhouse</h4>
                                <p>22 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-synagogue"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Villa</h4>
                                <p>18 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-mosque"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Offices</h4>
                                <p>42 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-tree-city"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Warehouses</h4>
                                <p>63 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-house"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Private House</h4>
                                <p>12 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-landmark-dome"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Openhouse</h4>
                                <p>16 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-city"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Building</h4>
                                <p>19 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-warehouse"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Shops</h4>
                                <p>17 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-shop-lock"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Studio</h4>
                                <p>10 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6">
                    <div class="classical-cats-wrap style_2 shadows">
                        <a class="classical-cats-boxs bg-white rounded-4 px-3 py-4">
                            <div class="classical-cats-icon circle bg-light-info text-main fs-2">
                                <i class="fa-solid fa-building-columns"></i>
                            </div>
                            <div class="classical-cats-wrap-content">
                                <h4>Condos</h4>
                                <p>31 Properties</p>
                            </div>
                        </a>
                    </div>
                </div>

            </div>

        </div>
    </section>
    <div class="clearfix"></div>
    <!-- ================================ Category End ======================================== -->

    <!-- ================================ All Property ========================================= -->
    <section class="gray-simple">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-7 col-md-10 text-center">
                    <div class="sec-heading mss">
                        <h2>Featured Property For Rent</h2>
                        <p>At vero eos et accusamus dignissimos ducimus</p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center g-4">

                <!-- Single Property -->
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                    <div class="property-listing card border-0 rounded-3">

                        <div class="listing-img-wrapper p-3">
                            <div class="position-relative">
                                <div class=" position-absolute top-0 left-0 ms-3 mt-3 z-1">
                                    <div
                                        class="label verified-listing d-inline-flex align-items-center justify-content-center">
                                        <span class="svg-icon text-light svg-icon-2hx me-1">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3"
                                                    d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z"
                                                    fill="currentColor"></path>
                                                <path
                                                    d="M14.854 11.321C14.7568 11.2282 14.6388 11.1818 14.4998 11.1818H14.3333V10.2272C14.3333 9.61741 14.1041 9.09378 13.6458 8.65628C13.1875 8.21876 12.639 8 12 8C11.361 8 10.8124 8.21876 10.3541 8.65626C9.89574 9.09378 9.66663 9.61739 9.66663 10.2272V11.1818H9.49999C9.36115 11.1818 9.24306 11.2282 9.14583 11.321C9.0486 11.4138 9 11.5265 9 11.6591V14.5227C9 14.6553 9.04862 14.768 9.14583 14.8609C9.24306 14.9536 9.36115 15 9.49999 15H14.5C14.6389 15 14.7569 14.9536 14.8542 14.8609C14.9513 14.768 15 14.6553 15 14.5227V11.6591C15.0001 11.5265 14.9513 11.4138 14.854 11.321ZM13.3333 11.1818H10.6666V10.2272C10.6666 9.87594 10.7969 9.57597 11.0573 9.32743C11.3177 9.07886 11.6319 8.9546 12 8.9546C12.3681 8.9546 12.6823 9.07884 12.9427 9.32743C13.2031 9.57595 13.3333 9.87594 13.3333 10.2272V11.1818Z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </span>Verified
                                    </div>
                                </div>
                                <div class="list-img-slide">
                                    <div class="click mb-0 rounded-3 overflow-hidden">
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-1.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-9.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-10.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="listing-caption-wrapper px-3">
                            <div class="listing-detail-wrapper">
                                <div class="listing-short-detail-wrap">
                                    <div class="listing-short-detail">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="label for-rent prt-type me-2">For Rent</span><span
                                                class="label property-type property-cats">Apartment</span>
                                        </div>
                                        <h4 class="listing-name fw-medium fs-6 mb-0"><a
                                                href="single-property-1.html" class="prt-link-detail">Equitable
                                                Property Group</a></h4>
                                        <div class="prt-location text-muted-2">
                                            <span class="svg-icon svg-icon-2hx">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3"
                                                        d="M18.0624 15.3453L13.1624 20.7453C12.5624 21.4453 11.5624 21.4453 10.9624 20.7453L6.06242 15.3453C4.56242 13.6453 3.76242 11.4453 4.06242 8.94534C4.56242 5.34534 7.46242 2.44534 11.0624 2.04534C15.8624 1.54534 19.9624 5.24534 19.9624 9.94534C20.0624 12.0453 19.2624 13.9453 18.0624 15.3453Z"
                                                        fill="currentColor"></path>
                                                    <path
                                                        d="M12.0624 13.0453C13.7193 13.0453 15.0624 11.7022 15.0624 10.0453C15.0624 8.38849 13.7193 7.04535 12.0624 7.04535C10.4056 7.04535 9.06241 8.38849 9.06241 10.0453C9.06241 11.7022 10.4056 13.0453 12.0624 13.0453Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            210 Zirak Road, Canada
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="price-features-wrapper d-flex align-items-center justify-content-between my-4">
                                <div class="listing-short-detail-flex">
                                    <h6 class="listing-card-info-price text-main ps-0 m-0">$78,500</h6>
                                </div>
                                <div class="lst-short-btns-groups d-flex align-items-center">
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-code-compare"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-envelope-open-text"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light"><i
                                            class="fa-solid fa-heart-circle-check"></i></a>
                                </div>
                            </div>
                        </div>
                        <div
                            class="lst-detail-footer d-flex align-items-center justify-content-between border-top py-2 px-3">
                            <div class="footer-first">
                                <div class="foot-reviews-wrap">
                                    <div class="foot-reviews-stars">
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                    </div>
                                    <div class="foot-reviews-subtitle">
                                        <span class="text-muted">47 Reviews</span>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-flex">
                                <div class="list-fx-features d-flex align-items-center justify-content-between m-0">
                                    <div class="listing-card d-flex align-items-center me-3">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-building-shield fs-sm"></i></div><span
                                            class="text-muted-2">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-clone fs-sm"></i></div><span
                                            class="text-muted-2">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- End Single Property -->

                <!-- Single Property -->
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                    <div class="property-listing card border-0 rounded-3">

                        <div class="listing-img-wrapper p-3">
                            <div class="position-relative">
                                <div class="position-absolute top-0 left-0 ms-3 mt-3 z-1">
                                    <div
                                        class="label super-agent d-inline-flex align-items-center justify-content-center">
                                        <span class="svg-icon text-light svg-icon-2hx me-1">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3"
                                                    d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M12.0006 11.1542C13.1434 11.1542 14.0777 10.22 14.0777 9.0771C14.0777 7.93424 13.1434 7 12.0006 7C10.8577 7 9.92348 7.93424 9.92348 9.0771C9.92348 10.22 10.8577 11.1542 12.0006 11.1542Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M15.5652 13.814C15.5108 13.6779 15.4382 13.551 15.3566 13.4331C14.9393 12.8163 14.2954 12.4081 13.5697 12.3083C13.479 12.2993 13.3793 12.3174 13.3067 12.3718C12.9257 12.653 12.4722 12.7981 12.0006 12.7981C11.5289 12.7981 11.0754 12.653 10.6944 12.3718C10.6219 12.3174 10.5221 12.2902 10.4314 12.3083C9.70578 12.4081 9.05272 12.8163 8.64456 13.4331C8.56293 13.551 8.49036 13.687 8.43595 13.814C8.40875 13.8684 8.41781 13.9319 8.44502 13.9864C8.51759 14.1133 8.60828 14.2403 8.68991 14.3492C8.81689 14.5215 8.95295 14.6757 9.10715 14.8208C9.23413 14.9478 9.37925 15.0657 9.52439 15.1836C10.2409 15.7188 11.1026 15.9999 11.9915 15.9999C12.8804 15.9999 13.7421 15.7188 14.4586 15.1836C14.6038 15.0748 14.7489 14.9478 14.8759 14.8208C15.021 14.6757 15.1661 14.5215 15.2931 14.3492C15.3838 14.2312 15.4655 14.1133 15.538 13.9864C15.5833 13.9319 15.5924 13.8684 15.5652 13.814Z"
                                                    fill="currentColor" />
                                            </svg>
                                        </span>SuperAgent
                                    </div>
                                </div>
                                <div class="list-img-slide">
                                    <div class="click mb-0 rounded-3 overflow-hidden">
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-2.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-6.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-8.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="listing-caption-wrapper px-3">
                            <div class="listing-detail-wrapper">
                                <div class="listing-short-detail-wrap">
                                    <div class="listing-short-detail">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="label for-rent prt-type me-2">For Rent</span><span
                                                class="label property-type property-cats">Apartment</span>
                                        </div>
                                        <h4 class="listing-name fw-medium fs-6 mb-0"><a
                                                href="single-property-1.html" class="prt-link-detail">Purple
                                                Flatiron House</a></h4>
                                        <div class="prt-location text-muted-2">
                                            <span class="svg-icon svg-icon-2hx">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3"
                                                        d="M18.0624 15.3453L13.1624 20.7453C12.5624 21.4453 11.5624 21.4453 10.9624 20.7453L6.06242 15.3453C4.56242 13.6453 3.76242 11.4453 4.06242 8.94534C4.56242 5.34534 7.46242 2.44534 11.0624 2.04534C15.8624 1.54534 19.9624 5.24534 19.9624 9.94534C20.0624 12.0453 19.2624 13.9453 18.0624 15.3453Z"
                                                        fill="currentColor"></path>
                                                    <path
                                                        d="M12.0624 13.0453C13.7193 13.0453 15.0624 11.7022 15.0624 10.0453C15.0624 8.38849 13.7193 7.04535 12.0624 7.04535C10.4056 7.04535 9.06241 8.38849 9.06241 10.0453C9.06241 11.7022 10.4056 13.0453 12.0624 13.0453Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            210 Zirak Road, Canada
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="price-features-wrapper d-flex align-items-center justify-content-between my-4">
                                <div class="listing-short-detail-flex">
                                    <h6 class="listing-card-info-price text-main ps-0 m-0">$67,000</h6>
                                </div>
                                <div class="lst-short-btns-groups d-flex align-items-center">
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-code-compare"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-envelope-open-text"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light"><i
                                            class="fa-solid fa-heart-circle-check"></i></a>
                                </div>
                            </div>
                        </div>
                        <div
                            class="lst-detail-footer d-flex align-items-center justify-content-between border-top py-2 px-3">
                            <div class="footer-first">
                                <div class="foot-reviews-wrap">
                                    <div class="foot-reviews-stars">
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                    </div>
                                    <div class="foot-reviews-subtitle">
                                        <span class="text-muted">102 Reviews</span>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-flex">
                                <div class="list-fx-features d-flex align-items-center justify-content-between m-0">
                                    <div class="listing-card d-flex align-items-center me-3">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-building-shield fs-sm"></i></div><span
                                            class="text-muted-2">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-clone fs-sm"></i></div><span
                                            class="text-muted-2">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- End Single Property -->

                <!-- Single Property -->
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                    <div class="property-listing card border-0 rounded-3">

                        <div class="listing-img-wrapper p-3">
                            <div class="position-relative">
                                <div class="position-absolute top-0 left-0 ms-3 mt-3 z-1">
                                    <div
                                        class="label verified-listing d-inline-flex align-items-center justify-content-center">
                                        <span class="svg-icon text-light svg-icon-2hx me-1">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3"
                                                    d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z"
                                                    fill="currentColor"></path>
                                                <path
                                                    d="M14.854 11.321C14.7568 11.2282 14.6388 11.1818 14.4998 11.1818H14.3333V10.2272C14.3333 9.61741 14.1041 9.09378 13.6458 8.65628C13.1875 8.21876 12.639 8 12 8C11.361 8 10.8124 8.21876 10.3541 8.65626C9.89574 9.09378 9.66663 9.61739 9.66663 10.2272V11.1818H9.49999C9.36115 11.1818 9.24306 11.2282 9.14583 11.321C9.0486 11.4138 9 11.5265 9 11.6591V14.5227C9 14.6553 9.04862 14.768 9.14583 14.8609C9.24306 14.9536 9.36115 15 9.49999 15H14.5C14.6389 15 14.7569 14.9536 14.8542 14.8609C14.9513 14.768 15 14.6553 15 14.5227V11.6591C15.0001 11.5265 14.9513 11.4138 14.854 11.321ZM13.3333 11.1818H10.6666V10.2272C10.6666 9.87594 10.7969 9.57597 11.0573 9.32743C11.3177 9.07886 11.6319 8.9546 12 8.9546C12.3681 8.9546 12.6823 9.07884 12.9427 9.32743C13.2031 9.57595 13.3333 9.87594 13.3333 10.2272V11.1818Z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </span>Verified
                                    </div>
                                    <div
                                        class="label new-listing d-inline-flex align-items-center justify-content-center ms-1">
                                        <span class="svg-icon text-light svg-icon-2hx me-1">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M19.0647 5.43757C19.3421 5.43757 19.567 5.21271 19.567 4.93534C19.567 4.65796 19.3421 4.43311 19.0647 4.43311C18.7874 4.43311 18.5625 4.65796 18.5625 4.93534C18.5625 5.21271 18.7874 5.43757 19.0647 5.43757Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M20.0692 9.48884C20.3466 9.48884 20.5714 9.26398 20.5714 8.98661C20.5714 8.70923 20.3466 8.48438 20.0692 8.48438C19.7918 8.48438 19.567 8.70923 19.567 8.98661C19.567 9.26398 19.7918 9.48884 20.0692 9.48884Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M12.0335 20.5714C15.6943 20.5714 18.9426 18.2053 20.1168 14.7338C20.1884 14.5225 20.1114 14.289 19.9284 14.161C19.746 14.034 19.5003 14.0418 19.3257 14.1821C18.2432 15.0546 16.9371 15.5156 15.5491 15.5156C12.2257 15.5156 9.48884 12.8122 9.48884 9.48886C9.48884 7.41079 10.5773 5.47137 12.3449 4.35752C12.5342 4.23832 12.6 4.00733 12.5377 3.79251C12.4759 3.57768 12.2571 3.42859 12.0335 3.42859C7.32556 3.42859 3.42857 7.29209 3.42857 12C3.42857 16.7079 7.32556 20.5714 12.0335 20.5714Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M13.0379 7.47998C13.8688 7.47998 14.5446 8.15585 14.5446 8.98668C14.5446 9.26428 14.7693 9.48891 15.0469 9.48891C15.3245 9.48891 15.5491 9.26428 15.5491 8.98668C15.5491 8.15585 16.225 7.47998 17.0558 7.47998C17.3334 7.47998 17.558 7.25535 17.558 6.97775C17.558 6.70015 17.3334 6.47552 17.0558 6.47552C16.225 6.47552 15.5491 5.76616 15.5491 4.93534C15.5491 4.65774 15.3245 4.43311 15.0469 4.43311C14.7693 4.43311 14.5446 4.65774 14.5446 4.93534C14.5446 5.76616 13.8688 6.47552 13.0379 6.47552C12.7603 6.47552 12.5357 6.70015 12.5357 6.97775C12.5357 7.25535 12.7603 7.47998 13.0379 7.47998Z"
                                                    fill="currentColor" />
                                            </svg>
                                        </span>New
                                    </div>
                                </div>
                                <div class="list-img-slide">
                                    <div class="click mb-0 rounded-3 overflow-hidden">
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-3.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-5.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-7.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="listing-caption-wrapper px-3">
                            <div class="listing-detail-wrapper">
                                <div class="listing-short-detail-wrap">
                                    <div class="listing-short-detail">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="label for-rent prt-type me-2">For Rent</span><span
                                                class="label property-type property-cats">Apartment</span>
                                        </div>
                                        <h4 class="listing-name fw-medium fs-6 mb-0"><a
                                                href="single-property-1.html" class="prt-link-detail">Rustic Reunion
                                                Tower</a></h4>
                                        <div class="prt-location text-muted-2">
                                            <span class="svg-icon svg-icon-2hx">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3"
                                                        d="M18.0624 15.3453L13.1624 20.7453C12.5624 21.4453 11.5624 21.4453 10.9624 20.7453L6.06242 15.3453C4.56242 13.6453 3.76242 11.4453 4.06242 8.94534C4.56242 5.34534 7.46242 2.44534 11.0624 2.04534C15.8624 1.54534 19.9624 5.24534 19.9624 9.94534C20.0624 12.0453 19.2624 13.9453 18.0624 15.3453Z"
                                                        fill="currentColor"></path>
                                                    <path
                                                        d="M12.0624 13.0453C13.7193 13.0453 15.0624 11.7022 15.0624 10.0453C15.0624 8.38849 13.7193 7.04535 12.0624 7.04535C10.4056 7.04535 9.06241 8.38849 9.06241 10.0453C9.06241 11.7022 10.4056 13.0453 12.0624 13.0453Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            210 Zirak Road, Canada
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="price-features-wrapper d-flex align-items-center justify-content-between my-4">
                                <div class="listing-short-detail-flex">
                                    <h6 class="listing-card-info-price text-main ps-0 m-0">$87,900</h6>
                                </div>
                                <div class="lst-short-btns-groups d-flex align-items-center">
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-code-compare"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-envelope-open-text"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light"><i
                                            class="fa-solid fa-heart-circle-check"></i></a>
                                </div>
                            </div>
                        </div>
                        <div
                            class="lst-detail-footer d-flex align-items-center justify-content-between border-top py-2 px-3">
                            <div class="footer-first">
                                <div class="foot-reviews-wrap">
                                    <div class="foot-reviews-stars">
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                    </div>
                                    <div class="foot-reviews-subtitle">
                                        <span class="text-muted">89 Reviews</span>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-flex">
                                <div class="list-fx-features d-flex align-items-center justify-content-between m-0">
                                    <div class="listing-card d-flex align-items-center me-3">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-building-shield fs-sm"></i></div><span
                                            class="text-muted-2">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-clone fs-sm"></i></div><span
                                            class="text-muted-2">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- End Single Property -->

                <!-- Single Property -->
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                    <div class="property-listing card border-0 rounded-3">

                        <div class="listing-img-wrapper p-3">
                            <div class="position-relative">
                                <div class="position-absolute top-0 left-0 ms-3 mt-3 z-1">
                                    <div
                                        class="label super-agent d-inline-flex align-items-center justify-content-center">
                                        <span class="svg-icon text-light svg-icon-2hx me-1">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3"
                                                    d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M12.0006 11.1542C13.1434 11.1542 14.0777 10.22 14.0777 9.0771C14.0777 7.93424 13.1434 7 12.0006 7C10.8577 7 9.92348 7.93424 9.92348 9.0771C9.92348 10.22 10.8577 11.1542 12.0006 11.1542Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M15.5652 13.814C15.5108 13.6779 15.4382 13.551 15.3566 13.4331C14.9393 12.8163 14.2954 12.4081 13.5697 12.3083C13.479 12.2993 13.3793 12.3174 13.3067 12.3718C12.9257 12.653 12.4722 12.7981 12.0006 12.7981C11.5289 12.7981 11.0754 12.653 10.6944 12.3718C10.6219 12.3174 10.5221 12.2902 10.4314 12.3083C9.70578 12.4081 9.05272 12.8163 8.64456 13.4331C8.56293 13.551 8.49036 13.687 8.43595 13.814C8.40875 13.8684 8.41781 13.9319 8.44502 13.9864C8.51759 14.1133 8.60828 14.2403 8.68991 14.3492C8.81689 14.5215 8.95295 14.6757 9.10715 14.8208C9.23413 14.9478 9.37925 15.0657 9.52439 15.1836C10.2409 15.7188 11.1026 15.9999 11.9915 15.9999C12.8804 15.9999 13.7421 15.7188 14.4586 15.1836C14.6038 15.0748 14.7489 14.9478 14.8759 14.8208C15.021 14.6757 15.1661 14.5215 15.2931 14.3492C15.3838 14.2312 15.4655 14.1133 15.538 13.9864C15.5833 13.9319 15.5924 13.8684 15.5652 13.814Z"
                                                    fill="currentColor" />
                                            </svg>
                                        </span>SuperAgent
                                    </div>
                                </div>
                                <div class="list-img-slide">
                                    <div class="click mb-0 rounded-3 overflow-hidden">
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-4.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-6.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-9.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="listing-caption-wrapper px-3">
                            <div class="listing-detail-wrapper">
                                <div class="listing-short-detail-wrap">
                                    <div class="listing-short-detail">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="label for-rent prt-type me-2">For Rent</span><span
                                                class="label property-type property-cats">Apartment</span>
                                        </div>
                                        <h4 class="listing-name fw-medium fs-6 mb-0"><a
                                                href="single-property-1.html" class="prt-link-detail">The Red
                                                Freedom Tower</a></h4>
                                        <div class="prt-location text-muted-2">
                                            <span class="svg-icon svg-icon-2hx">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3"
                                                        d="M18.0624 15.3453L13.1624 20.7453C12.5624 21.4453 11.5624 21.4453 10.9624 20.7453L6.06242 15.3453C4.56242 13.6453 3.76242 11.4453 4.06242 8.94534C4.56242 5.34534 7.46242 2.44534 11.0624 2.04534C15.8624 1.54534 19.9624 5.24534 19.9624 9.94534C20.0624 12.0453 19.2624 13.9453 18.0624 15.3453Z"
                                                        fill="currentColor"></path>
                                                    <path
                                                        d="M12.0624 13.0453C13.7193 13.0453 15.0624 11.7022 15.0624 10.0453C15.0624 8.38849 13.7193 7.04535 12.0624 7.04535C10.4056 7.04535 9.06241 8.38849 9.06241 10.0453C9.06241 11.7022 10.4056 13.0453 12.0624 13.0453Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            210 Zirak Road, Canada
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="price-features-wrapper d-flex align-items-center justify-content-between my-4">
                                <div class="listing-short-detail-flex">
                                    <h6 class="listing-card-info-price text-main ps-0 m-0">$85,700</h6>
                                </div>
                                <div class="lst-short-btns-groups d-flex align-items-center">
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-code-compare"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-envelope-open-text"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light"><i
                                            class="fa-solid fa-heart-circle-check"></i></a>
                                </div>
                            </div>
                        </div>
                        <div
                            class="lst-detail-footer d-flex align-items-center justify-content-between border-top py-2 px-3">
                            <div class="footer-first">
                                <div class="foot-reviews-wrap">
                                    <div class="foot-reviews-stars">
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                    </div>
                                    <div class="foot-reviews-subtitle">
                                        <span class="text-muted">64 Reviews</span>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-flex">
                                <div class="list-fx-features d-flex align-items-center justify-content-between m-0">
                                    <div class="listing-card d-flex align-items-center me-3">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-building-shield fs-sm"></i></div><span
                                            class="text-muted-2">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-clone fs-sm"></i></div><span
                                            class="text-muted-2">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- End Single Property -->

                <!-- Single Property -->
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                    <div class="property-listing card border-0 rounded-3">

                        <div class="listing-img-wrapper p-3">
                            <div class="position-relative">
                                <div class="position-absolute top-0 left-0 ms-3 mt-3 z-1">
                                    <div
                                        class="label verified-listing d-inline-flex align-items-center justify-content-center">
                                        <span class="svg-icon text-light svg-icon-2hx me-1">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3"
                                                    d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z"
                                                    fill="currentColor"></path>
                                                <path
                                                    d="M14.854 11.321C14.7568 11.2282 14.6388 11.1818 14.4998 11.1818H14.3333V10.2272C14.3333 9.61741 14.1041 9.09378 13.6458 8.65628C13.1875 8.21876 12.639 8 12 8C11.361 8 10.8124 8.21876 10.3541 8.65626C9.89574 9.09378 9.66663 9.61739 9.66663 10.2272V11.1818H9.49999C9.36115 11.1818 9.24306 11.2282 9.14583 11.321C9.0486 11.4138 9 11.5265 9 11.6591V14.5227C9 14.6553 9.04862 14.768 9.14583 14.8609C9.24306 14.9536 9.36115 15 9.49999 15H14.5C14.6389 15 14.7569 14.9536 14.8542 14.8609C14.9513 14.768 15 14.6553 15 14.5227V11.6591C15.0001 11.5265 14.9513 11.4138 14.854 11.321ZM13.3333 11.1818H10.6666V10.2272C10.6666 9.87594 10.7969 9.57597 11.0573 9.32743C11.3177 9.07886 11.6319 8.9546 12 8.9546C12.3681 8.9546 12.6823 9.07884 12.9427 9.32743C13.2031 9.57595 13.3333 9.87594 13.3333 10.2272V11.1818Z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </span>Verified
                                    </div>
                                    <div
                                        class="label new-listing d-inline-flex align-items-center justify-content-center ms-1">
                                        <span class="svg-icon text-light svg-icon-2hx me-1">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M19.0647 5.43757C19.3421 5.43757 19.567 5.21271 19.567 4.93534C19.567 4.65796 19.3421 4.43311 19.0647 4.43311C18.7874 4.43311 18.5625 4.65796 18.5625 4.93534C18.5625 5.21271 18.7874 5.43757 19.0647 5.43757Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M20.0692 9.48884C20.3466 9.48884 20.5714 9.26398 20.5714 8.98661C20.5714 8.70923 20.3466 8.48438 20.0692 8.48438C19.7918 8.48438 19.567 8.70923 19.567 8.98661C19.567 9.26398 19.7918 9.48884 20.0692 9.48884Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M12.0335 20.5714C15.6943 20.5714 18.9426 18.2053 20.1168 14.7338C20.1884 14.5225 20.1114 14.289 19.9284 14.161C19.746 14.034 19.5003 14.0418 19.3257 14.1821C18.2432 15.0546 16.9371 15.5156 15.5491 15.5156C12.2257 15.5156 9.48884 12.8122 9.48884 9.48886C9.48884 7.41079 10.5773 5.47137 12.3449 4.35752C12.5342 4.23832 12.6 4.00733 12.5377 3.79251C12.4759 3.57768 12.2571 3.42859 12.0335 3.42859C7.32556 3.42859 3.42857 7.29209 3.42857 12C3.42857 16.7079 7.32556 20.5714 12.0335 20.5714Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M13.0379 7.47998C13.8688 7.47998 14.5446 8.15585 14.5446 8.98668C14.5446 9.26428 14.7693 9.48891 15.0469 9.48891C15.3245 9.48891 15.5491 9.26428 15.5491 8.98668C15.5491 8.15585 16.225 7.47998 17.0558 7.47998C17.3334 7.47998 17.558 7.25535 17.558 6.97775C17.558 6.70015 17.3334 6.47552 17.0558 6.47552C16.225 6.47552 15.5491 5.76616 15.5491 4.93534C15.5491 4.65774 15.3245 4.43311 15.0469 4.43311C14.7693 4.43311 14.5446 4.65774 14.5446 4.93534C14.5446 5.76616 13.8688 6.47552 13.0379 6.47552C12.7603 6.47552 12.5357 6.70015 12.5357 6.97775C12.5357 7.25535 12.7603 7.47998 13.0379 7.47998Z"
                                                    fill="currentColor" />
                                            </svg>
                                        </span>New
                                    </div>
                                </div>
                                <div class="list-img-slide">
                                    <div class="click mb-0 rounded-3 overflow-hidden">
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-5.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-12.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-13.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="listing-caption-wrapper px-3">
                            <div class="listing-detail-wrapper">
                                <div class="listing-short-detail-wrap">
                                    <div class="listing-short-detail">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="label for-rent prt-type me-2">For Rent</span><span
                                                class="label property-type property-cats">Apartment</span>
                                        </div>
                                        <h4 class="listing-name fw-medium fs-6 mb-0"><a
                                                href="single-property-1.html" class="prt-link-detail">The Donald
                                                Dwelling</a></h4>
                                        <div class="prt-location text-muted-2">
                                            <span class="svg-icon svg-icon-2hx">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3"
                                                        d="M18.0624 15.3453L13.1624 20.7453C12.5624 21.4453 11.5624 21.4453 10.9624 20.7453L6.06242 15.3453C4.56242 13.6453 3.76242 11.4453 4.06242 8.94534C4.56242 5.34534 7.46242 2.44534 11.0624 2.04534C15.8624 1.54534 19.9624 5.24534 19.9624 9.94534C20.0624 12.0453 19.2624 13.9453 18.0624 15.3453Z"
                                                        fill="currentColor"></path>
                                                    <path
                                                        d="M12.0624 13.0453C13.7193 13.0453 15.0624 11.7022 15.0624 10.0453C15.0624 8.38849 13.7193 7.04535 12.0624 7.04535C10.4056 7.04535 9.06241 8.38849 9.06241 10.0453C9.06241 11.7022 10.4056 13.0453 12.0624 13.0453Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            210 Zirak Road, Canada
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="price-features-wrapper d-flex align-items-center justify-content-between my-4">
                                <div class="listing-short-detail-flex">
                                    <h6 class="listing-card-info-price text-main ps-0 m-0">$78,400</h6>
                                </div>
                                <div class="lst-short-btns-groups d-flex align-items-center">
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-code-compare"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-envelope-open-text"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light"><i
                                            class="fa-solid fa-heart-circle-check"></i></a>
                                </div>
                            </div>
                        </div>
                        <div
                            class="lst-detail-footer d-flex align-items-center justify-content-between border-top py-2 px-3">
                            <div class="footer-first">
                                <div class="foot-reviews-wrap">
                                    <div class="foot-reviews-stars">
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                    </div>
                                    <div class="foot-reviews-subtitle">
                                        <span class="text-muted">65 Reviews</span>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-flex">
                                <div class="list-fx-features d-flex align-items-center justify-content-between m-0">
                                    <div class="listing-card d-flex align-items-center me-3">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-building-shield fs-sm"></i></div><span
                                            class="text-muted-2">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-clone fs-sm"></i></div><span
                                            class="text-muted-2">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- End Single Property -->

                <!-- Single Property -->
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                    <div class="property-listing card border-0 rounded-3">

                        <div class="listing-img-wrapper p-3">
                            <div class="position-relative">
                                <div class="position-absolute top-0 left-0 ms-3 mt-3 z-1">
                                    <div
                                        class="label super-agent d-inline-flex align-items-center justify-content-center">
                                        <span class="svg-icon text-light svg-icon-2hx me-1">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3"
                                                    d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M12.0006 11.1542C13.1434 11.1542 14.0777 10.22 14.0777 9.0771C14.0777 7.93424 13.1434 7 12.0006 7C10.8577 7 9.92348 7.93424 9.92348 9.0771C9.92348 10.22 10.8577 11.1542 12.0006 11.1542Z"
                                                    fill="currentColor" />
                                                <path
                                                    d="M15.5652 13.814C15.5108 13.6779 15.4382 13.551 15.3566 13.4331C14.9393 12.8163 14.2954 12.4081 13.5697 12.3083C13.479 12.2993 13.3793 12.3174 13.3067 12.3718C12.9257 12.653 12.4722 12.7981 12.0006 12.7981C11.5289 12.7981 11.0754 12.653 10.6944 12.3718C10.6219 12.3174 10.5221 12.2902 10.4314 12.3083C9.70578 12.4081 9.05272 12.8163 8.64456 13.4331C8.56293 13.551 8.49036 13.687 8.43595 13.814C8.40875 13.8684 8.41781 13.9319 8.44502 13.9864C8.51759 14.1133 8.60828 14.2403 8.68991 14.3492C8.81689 14.5215 8.95295 14.6757 9.10715 14.8208C9.23413 14.9478 9.37925 15.0657 9.52439 15.1836C10.2409 15.7188 11.1026 15.9999 11.9915 15.9999C12.8804 15.9999 13.7421 15.7188 14.4586 15.1836C14.6038 15.0748 14.7489 14.9478 14.8759 14.8208C15.021 14.6757 15.1661 14.5215 15.2931 14.3492C15.3838 14.2312 15.4655 14.1133 15.538 13.9864C15.5833 13.9319 15.5924 13.8684 15.5652 13.814Z"
                                                    fill="currentColor" />
                                            </svg>
                                        </span>SuperAgent
                                    </div>
                                </div>
                                <div class="list-img-slide">
                                    <div class="click mb-0 rounded-3 overflow-hidden">
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-6.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-7.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                        <div><a href="single-property-1.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/p-11.jpg"
                                                    class="img-fluid" alt="" /></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="listing-caption-wrapper px-3">
                            <div class="listing-detail-wrapper">
                                <div class="listing-short-detail-wrap">
                                    <div class="listing-short-detail">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="label for-rent prt-type me-2">For Rent</span><span
                                                class="label property-type property-cats">Apartment</span>
                                        </div>
                                        <h4 class="listing-name fw-medium fs-6 mb-0"><a
                                                href="single-property-1.html" class="prt-link-detail">Red Tiny
                                                Hearst Castle</a></h4>
                                        <div class="prt-location text-muted-2">
                                            <span class="svg-icon svg-icon-2hx">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3"
                                                        d="M18.0624 15.3453L13.1624 20.7453C12.5624 21.4453 11.5624 21.4453 10.9624 20.7453L6.06242 15.3453C4.56242 13.6453 3.76242 11.4453 4.06242 8.94534C4.56242 5.34534 7.46242 2.44534 11.0624 2.04534C15.8624 1.54534 19.9624 5.24534 19.9624 9.94534C20.0624 12.0453 19.2624 13.9453 18.0624 15.3453Z"
                                                        fill="currentColor"></path>
                                                    <path
                                                        d="M12.0624 13.0453C13.7193 13.0453 15.0624 11.7022 15.0624 10.0453C15.0624 8.38849 13.7193 7.04535 12.0624 7.04535C10.4056 7.04535 9.06241 8.38849 9.06241 10.0453C9.06241 11.7022 10.4056 13.0453 12.0624 13.0453Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            210 Zirak Road, Canada
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="price-features-wrapper d-flex align-items-center justify-content-between my-4">
                                <div class="listing-short-detail-flex">
                                    <h6 class="listing-card-info-price text-main ps-0 m-0">$78,500</h6>
                                </div>
                                <div class="lst-short-btns-groups d-flex align-items-center">
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-code-compare"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light me-2"><i
                                            class="fa-solid fa-envelope-open-text"></i></a>
                                    <a href="JavaScript:Void(0);" class="square--40 circle bg-light"><i
                                            class="fa-solid fa-heart-circle-check"></i></a>
                                </div>
                            </div>
                        </div>
                        <div
                            class="lst-detail-footer d-flex align-items-center justify-content-between border-top py-2 px-3">
                            <div class="footer-first">
                                <div class="foot-reviews-wrap">
                                    <div class="foot-reviews-stars">
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                        <span><i class="fa-solid fa-star text-warning fs-sm"></i></span>
                                    </div>
                                    <div class="foot-reviews-subtitle">
                                        <span class="text-muted">47 Reviews</span>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-flex">
                                <div class="list-fx-features d-flex align-items-center justify-content-between m-0">
                                    <div class="listing-card d-flex align-items-center me-3">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-building-shield fs-sm"></i></div><span
                                            class="text-muted-2">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--30 text-muted-2 fs-sm circle gray-simple me-2"><i
                                                class="fa-solid fa-clone fs-sm"></i></div><span
                                            class="text-muted-2">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- End Single Property -->

            </div>

            <div class="row align-items-center justify-content-center">
                <div class="col-lg-12 col-md-12 col-sm-12 text-center mt-5">
                    <a href="listings-list-with-sidebar.html" class="btn btn-main px-md-5 rounded">Browse More
                        Properties</a>
                </div>
            </div>

        </div>
    </section>
    <!-- ============================ All Featured Property ================================== -->

    <!-- ============================ Latest Property For Sale Start ================================== -->
    <section class="bg-light">
        <div class="container">

            <div class="row align-items-center justify-content-between">

                <div class="col-xl-3 col-lg-4 col-md-4 col-sm-12">
                    <div class="trustscrore-wrap">
                        <div class="trustscrore-title">
                            <h2>4.8</h2>
                        </div>
                        <div class="trustscrore-rates">
                            <div class="trustscrore-stars">
                                <span><i class="fa-solid fa-star"></i></span>
                                <span><i class="fa-solid fa-star"></i></span>
                                <span><i class="fa-solid fa-star"></i></span>
                                <span><i class="fa-solid fa-star"></i></span>
                                <span><i class="fa-solid fa-star"></i></span>
                            </div>
                            <div class="trustscrore-stars-title"><span>Trustscore on 176 Reviews</span></div>
                        </div>

                        <div class="trustscrore-info">
                            <div class="trustscrore-subtitle"><span>Check all reviews on</span></div>
                            <div class="trustscrore-brand"><img src="<?php echo e(asset('frontEnd')); ?>/img/brand.png" class="img-fluid" alt="">
                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12">
                    <div class="single-reviews">

                        <!-- Single Item -->
                        <div class="single-item-reviews">
                            <div class="single-item-reviews-desc">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                    nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                    fugiat nulla pariatur.</p>
                            </div>
                            <div class="single-item-reviews-info">
                                <h4>Harman Preet</h4>
                                <p class="text-main">Google Manager</p>
                            </div>
                        </div>

                        <!-- Single Item -->
                        <div class="single-item-reviews">
                            <div class="single-item-reviews-desc">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                    nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                    fugiat nulla pariatur.</p>
                            </div>
                            <div class="single-item-reviews-info">
                                <h4>Bharti Patel</h4>
                                <p class="text-main">BootstrapWire Manager</p>
                            </div>
                        </div>

                        <!-- Single Item -->
                        <div class="single-item-reviews">
                            <div class="single-item-reviews-desc">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                    nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                    fugiat nulla pariatur.</p>
                            </div>
                            <div class="single-item-reviews-info">
                                <h4>Dhananjay Verma</h4>
                                <p class="text-main">Themezhub Manager</p>
                            </div>
                        </div>

                        <!-- Single Item -->
                        <div class="single-item-reviews">
                            <div class="single-item-reviews-desc">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                    nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                    fugiat nulla pariatur.</p>
                            </div>
                            <div class="single-item-reviews-info">
                                <h4>Shreekant Tripathi</h4>
                                <p class="text-main">Megroo Developer</p>
                            </div>
                        </div>

                        <!-- Single Item -->
                        <div class="single-item-reviews">
                            <div class="single-item-reviews-desc">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                                    nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                    fugiat nulla pariatur.</p>
                            </div>
                            <div class="single-item-reviews-info">
                                <h4>Rajnish Shukla</h4>
                                <p class="text-main">Airbnb Leader</p>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

            <div class="row align-items-center justify-content-between">
                <div class="col-xl-12 col-lg-12 col-md-12">

                    <div class="counter-info-groups">

                        <div class="single-counter-wrap">
                            <div class="single-counter-title">
                                <h2>$<span class="ctr">310</span>M</h2>
                            </div>
                            <div class="single-counter-subtitle">
                                <p>Owned from<br>properties transaction</p>
                            </div>
                        </div>

                        <div class="single-counter-wrap">
                            <div class="single-counter-title">
                                <h2><span class="ctr">40</span>K</h2>
                            </div>
                            <div class="single-counter-subtitle">
                                <p>Properties for<br>Buy & Sell</p>
                            </div>
                        </div>

                        <div class="single-counter-wrap">
                            <div class="single-counter-title">
                                <h2><span class="ctr">500</span></h2>
                            </div>
                            <div class="single-counter-subtitle">
                                <p>Daily Completed<br>transaction</p>
                            </div>
                        </div>
                        <div class="single-counter-wrap">
                            <div class="single-counter-title">
                                <h2><span class="ctr">114</span>M</h2>
                            </div>
                            <div class="single-counter-subtitle">
                                <p>Happy Customers<br>from Resido</p>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

        </div>
    </section>
    <!-- ============================ Latest Property For Sale End ================================== -->

    <!-- ============================ All Property ================================== -->
    <section>
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-lg-7 col-md-10 text-center">
                    <div class="sec-heading center">
                        <h2>Featured Property For Sale</h2>
                        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                            voluptatum deleniti atque corrupti quos dolores</p>
                    </div>
                </div>
            </div>

            <div class="row list-layout">

                <!-- Single Property Start -->
                <div class="col-xl-6 col-lg-6 col-md-12">
                    <div class="property-listing property-1 bg-white p-2 rounded border">

                        <div class="listing-img-wrapper">
                            <a href="single-property-2.html">
                                <img src="<?php echo e(asset('frontEnd')); ?>/img/p-1.jpg" class="img-fluid mx-auto rounded" alt="" />
                            </a>
                        </div>

                        <div class="listing-content">

                            <div class="listing-detail-wrapper-box">
                                <div
                                    class="listing-detail-wrapper d-flex align-items-center justify-content-between">
                                    <div class="listing-short-detail">
                                        <span class="label for-sale d-inline-flex mb-1">For Sale</span>
                                        <h4 class="listing-name mb-0"><a href="single-property-2.html">Adobe
                                                Property Advisors</a></h4>
                                        <div class="fr-can-rating">
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs"></i>
                                            <span class="reviews_text fs-sm text-muted ms-2">(42 Reviews)</span>
                                        </div>

                                    </div>
                                    <div class="list-price">
                                        <h6 class="listing-card-info-price text-main">$120M</h6>
                                    </div>
                                </div>
                            </div>

                            <div class="price-features-wrapper">
                                <div
                                    class="list-fx-features d-flex align-items-center justify-content-between mt-3 mb-1">
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-building-shield fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-bed fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">3 Beds</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-clone fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>

                            <div class="listing-footer-wrapper">
                                <div class="listing-locate">
                                    <span class="listing-location text-muted-2"><i
                                            class="fa-solid fa-location-pin me-1"></i>Quice Market, Canada</span>
                                </div>
                                <div class="listing-detail-btn">
                                    <a href="single-property-2.html"
                                        class="btn btn-sm px-4 fw-medium btn-main">View</a>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <!-- Single Property End -->

                <!-- Single Property Start -->
                <div class="col-xl-6 col-lg-6 col-md-12">
                    <div class="property-listing property-1 bg-white p-2 rounded border">

                        <div class="listing-img-wrapper">
                            <a href="single-property-2.html">
                                <img src="<?php echo e(asset('frontEnd')); ?>/img/p-2.jpg" class="img-fluid mx-auto rounded" alt="" />
                            </a>
                        </div>

                        <div class="listing-content">

                            <div class="listing-detail-wrapper-box">
                                <div
                                    class="listing-detail-wrapper d-flex align-items-center justify-content-between">
                                    <div class="listing-short-detail">
                                        <span class="label for-sale d-inline-flex mb-1">For Sale</span>
                                        <h4 class="listing-name mb-0"><a href="single-property-2.html">Agile Real
                                                Estate Group</a></h4>
                                        <div class="fr-can-rating">
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs"></i>
                                            <span class="reviews_text fs-sm text-muted ms-2">(34 Reviews)</span>
                                        </div>

                                    </div>
                                    <div class="list-price">
                                        <h6 class="listing-card-info-price text-main">$132M</h6>
                                    </div>
                                </div>
                            </div>

                            <div class="price-features-wrapper">
                                <div
                                    class="list-fx-features d-flex align-items-center justify-content-between mt-3 mb-1">
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-building-shield fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-bed fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">3 Beds</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-clone fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>

                            <div class="listing-footer-wrapper">
                                <div class="listing-locate">
                                    <span class="listing-location text-muted-2"><i
                                            class="fa-solid fa-location-pin me-1"></i>Quice Market, Canada</span>
                                </div>
                                <div class="listing-detail-btn">
                                    <a href="single-property-2.html"
                                        class="btn btn-sm px-4 fw-medium btn-main">View</a>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <!-- Single Property End -->

                <!-- Single Property Start -->
                <div class="col-xl-6 col-lg-6 col-md-12">
                    <div class="property-listing property-1 bg-white p-2 rounded border">

                        <div class="listing-img-wrapper">
                            <a href="single-property-2.html">
                                <img src="<?php echo e(asset('frontEnd')); ?>/img/p-3.jpg" class="img-fluid mx-auto rounded" alt="" />
                            </a>
                        </div>

                        <div class="listing-content">

                            <div class="listing-detail-wrapper-box">
                                <div
                                    class="listing-detail-wrapper d-flex align-items-center justify-content-between">
                                    <div class="listing-short-detail">
                                        <span class="label for-sale d-inline-flex mb-1">For Sale</span>
                                        <h4 class="listing-name mb-0"><a href="single-property-2.html">Bluebell Real
                                                Estate</a></h4>
                                        <div class="fr-can-rating">
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs"></i>
                                            <span class="reviews_text fs-sm text-muted ms-2">(124 Reviews)</span>
                                        </div>

                                    </div>
                                    <div class="list-price">
                                        <h6 class="listing-card-info-price text-main">$127M</h6>
                                    </div>
                                </div>
                            </div>

                            <div class="price-features-wrapper">
                                <div
                                    class="list-fx-features d-flex align-items-center justify-content-between mt-3 mb-1">
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-building-shield fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-bed fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">3 Beds</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-clone fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>

                            <div class="listing-footer-wrapper">
                                <div class="listing-locate">
                                    <span class="listing-location text-muted-2"><i
                                            class="fa-solid fa-location-pin me-1"></i>Quice Market, Canada</span>
                                </div>
                                <div class="listing-detail-btn">
                                    <a href="single-property-2.html"
                                        class="btn btn-sm px-4 fw-medium btn-main">View</a>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <!-- Single Property End -->

                <!-- Single Property Start -->
                <div class="col-xl-6 col-lg-6 col-md-12">
                    <div class="property-listing property-1 bg-white p-2 rounded border">

                        <div class="listing-img-wrapper">
                            <a href="single-property-2.html">
                                <img src="<?php echo e(asset('frontEnd')); ?>/img/p-4.jpg" class="img-fluid mx-auto rounded" alt="" />
                            </a>
                        </div>

                        <div class="listing-content">

                            <div class="listing-detail-wrapper-box">
                                <div
                                    class="listing-detail-wrapper d-flex align-items-center justify-content-between">
                                    <div class="listing-short-detail">
                                        <span class="label for-sale d-inline-flex mb-1">For Sale</span>
                                        <h4 class="listing-name mb-0"><a href="single-property-2.html">Strive
                                                Partners Realty</a></h4>
                                        <div class="fr-can-rating">
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <i class="fas fa-star fs-xs filled"></i>
                                            <span class="reviews_text fs-sm text-muted ms-2">(56 Reviews)</span>
                                        </div>

                                    </div>
                                    <div class="list-price">
                                        <h6 class="listing-card-info-price text-main">$132M</h6>
                                    </div>
                                </div>
                            </div>

                            <div class="price-features-wrapper">
                                <div
                                    class="list-fx-features d-flex align-items-center justify-content-between mt-3 mb-1">
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-building-shield fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">3BHK</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-bed fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">3 Beds</span>
                                    </div>
                                    <div class="listing-card d-flex align-items-center">
                                        <div class="square--25 text-muted-2 fs-sm circle gray-simple me-1"><i
                                                class="fa-solid fa-clone fs-xs"></i></div><span
                                            class="text-muted-2 fs-sm">1800 SQFT</span>
                                    </div>
                                </div>
                            </div>

                            <div class="listing-footer-wrapper">
                                <div class="listing-locate">
                                    <span class="listing-location text-muted-2"><i
                                            class="fa-solid fa-location-pin me-1"></i>Quice Market, Canada</span>
                                </div>
                                <div class="listing-detail-btn">
                                    <a href="single-property-2.html"
                                        class="btn btn-sm px-4 fw-medium btn-main">View</a>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <!-- Single Property End -->

            </div>

            <!-- Pagination -->
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 text-center mt-4">
                    <a href="listings-list-with-sidebar.html" class="btn btn-main px-lg-5 rounded">Browse More
                        Properties</a>
                </div>
            </div>

        </div>
    </section>
    <!-- ============================ All Featured Property ================================== -->

    <!-- ============================ Smart Testimonials ================================== -->
    <section class="gray-bg">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-lg-7 col-md-10 text-center">
                    <div class="sec-heading center">
                        <h2>Good Reviews by Customers</h2>
                        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                            voluptatum deleniti atque corrupti quos dolores</p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">

                <div class="col-lg-12 col-md-12">

                    <div class="smart-textimonials smart-center" id="smart-textimonials">

                        <!-- Single Item -->
                        <div class="item">
                            <div class="item-box">
                                <div class="smart-tes-author">
                                    <div class="st-author-box">
                                        <div class="st-author-thumb">
                                            <div class="quotes bg-main"><i class="fa-solid fa-quote-left"></i></div>
                                            <img src="<?php echo e(asset('frontEnd')); ?>/img/user-3.png" class="img-fluid" alt="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="smart-tes-content">
                                    <p>Cicero famously orated against his political opponent Lucius Sergius
                                        Catilina. Occasionally the first Oration against Catiline is taken
                                        specimens.</p>
                                </div>

                                <div class="st-author-info">
                                    <h4 class="st-author-title">Adam Williams</h4>
                                    <span class="st-author-subtitle">CEO Of Microwoft</span>
                                </div>
                            </div>
                        </div>

                        <!-- Single Item -->
                        <div class="item">
                            <div class="item-box">
                                <div class="smart-tes-author">
                                    <div class="st-author-box">
                                        <div class="st-author-thumb">
                                            <div class="quotes bg-green"><i class="fa-solid fa-quote-left"></i>
                                            </div>
                                            <img src="<?php echo e(asset('frontEnd')); ?>/img/user-8.png" class="img-fluid" alt="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="smart-tes-content">
                                    <p>Cicero famously orated against his political opponent Lucius Sergius
                                        Catilina. Occasionally the first Oration against Catiline is taken
                                        specimens.</p>
                                </div>

                                <div class="st-author-info">
                                    <h4 class="st-author-title">Retha Deowalim</h4>
                                    <span class="st-author-subtitle">CEO Of Apple</span>
                                </div>
                            </div>
                        </div>

                        <!-- Single Item -->
                        <div class="item">
                            <div class="item-box">
                                <div class="smart-tes-author">
                                    <div class="st-author-box">
                                        <div class="st-author-thumb">
                                            <div class="quotes bg-red"><i class="fa-solid fa-quote-left"></i></div>
                                            <img src="<?php echo e(asset('frontEnd')); ?>/img/user-4.png" class="img-fluid" alt="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="smart-tes-content">
                                    <p>Cicero famously orated against his political opponent Lucius Sergius
                                        Catilina. Occasionally the first Oration against Catiline is taken
                                        specimens.</p>
                                </div>

                                <div class="st-author-info">
                                    <h4 class="st-author-title">Sam J. Wasim</h4>
                                    <span class="st-author-subtitle">Pio Founder</span>
                                </div>
                            </div>
                        </div>

                        <!-- Single Item -->
                        <div class="item">
                            <div class="item-box">
                                <div class="smart-tes-author">
                                    <div class="st-author-box">
                                        <div class="st-author-thumb">
                                            <div class="quotes bg-primary"><i class="fa-solid fa-quote-left"></i>
                                            </div>
                                            <img src="<?php echo e(asset('frontEnd')); ?>/img/user-5.png" class="img-fluid" alt="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="smart-tes-content">
                                    <p>Cicero famously orated against his political opponent Lucius Sergius
                                        Catilina. Occasionally the first Oration against Catiline is taken
                                        specimens.</p>
                                </div>

                                <div class="st-author-info">
                                    <h4 class="st-author-title">Usan Gulwarm</h4>
                                    <span class="st-author-subtitle">CEO Of Facewarm</span>
                                </div>
                            </div>
                        </div>

                        <!-- Single Item -->
                        <div class="item">
                            <div class="item-box">
                                <div class="smart-tes-author">
                                    <div class="st-author-box">
                                        <div class="st-author-thumb">
                                            <div class="quotes bg-warning"><i class="fa-solid fa-quote-left"></i>
                                            </div>
                                            <img src="<?php echo e(asset('frontEnd')); ?>/img/user-6.png" class="img-fluid" alt="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="smart-tes-content">
                                    <p>Cicero famously orated against his political opponent Lucius Sergius
                                        Catilina. Occasionally the first Oration against Catiline is taken
                                        specimens.</p>
                                </div>

                                <div class="st-author-info">
                                    <h4 class="st-author-title">Shilpa Shethy</h4>
                                    <span class="st-author-subtitle">CEO Of Zapple</span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </section>
    <!-- ============================ Smart Testimonials End ================================== -->

    <!-- ================================= Blog Grid ================================== -->
    <section>
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-lg-7 col-md-10 text-center">
                    <div class="sec-heading center">
                        <h2>Latest Updates By Resido</h2>
                        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                            voluptatum deleniti atque corrupti quos dolores</p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center g-4">

                <!-- Single blog Grid -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="blog-wrap-grid h-100 shadow">

                        <div class="blog-thumb">
                            <a href="blog-detail.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/b-4.jpg" class="img-fluid" alt="" /></a>
                        </div>

                        <div class="blog-info">
                            <span class="post-date label bg-green text-light"><i class="ti-calendar"></i>30 july
                                2018</span>
                        </div>

                        <div class="blog-body">
                            <h4 class="bl-title fw-medium"><a href="blog-detail.html">Why people choose Resido for
                                    own properties</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore. </p>
                            <a href="blog-detail.html" class="text-main fw-medium">Continue<i
                                    class="fa-solid fa-arrow-right ms-2"></i></a>
                        </div>

                    </div>
                </div>

                <!-- Single blog Grid -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="blog-wrap-grid h-100 shadow">

                        <div class="blog-thumb fw-medium">
                            <a href="blog-detail.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/b-5.jpg" class="img-fluid" alt="" /></a>
                        </div>

                        <div class="blog-info">
                            <span class="post-date label bg-green text-light"><i class="ti-calendar"></i>10 August
                                2018</span>
                        </div>

                        <div class="blog-body">
                            <h4 class="bl-title"><a href="blog-detail.html">List of benifits and impressive Resido
                                    services</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore. </p>
                            <a href="blog-detail.html" class="text-main fw-medium">Continue<i
                                    class="fa-solid fa-arrow-right ms-2"></i></a>
                        </div>

                    </div>
                </div>

                <!-- Single blog Grid -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="blog-wrap-grid h-100 shadow">

                        <div class="blog-thumb">
                            <a href="blog-detail.html"><img src="<?php echo e(asset('frontEnd')); ?>/img/b-6.jpg" class="img-fluid" alt="" /></a>
                        </div>

                        <div class="blog-info">
                            <span class="post-date label bg-green text-light"><i class="ti-calendar"></i>30 Sep
                                2018</span>
                        </div>

                        <div class="blog-body">
                            <h4 class="bl-title fw-medium"><a href="blog-detail.html">What people says about Resido
                                    properties</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore. </p>
                            <a href="blog-detail.html" class="text-main fw-medium">Continue<i
                                    class="fa-solid fa-arrow-right ms-2"></i></a>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </section>
    <!-- ============================== Blog Grid End =============================== -->
<?php $__env->stopSection(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal292c42cda3271405dc664835e31595e3)): ?>
<?php $attributes = $__attributesOriginal292c42cda3271405dc664835e31595e3; ?>
<?php unset($__attributesOriginal292c42cda3271405dc664835e31595e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal292c42cda3271405dc664835e31595e3)): ?>
<?php $component = $__componentOriginal292c42cda3271405dc664835e31595e3; ?>
<?php unset($__componentOriginal292c42cda3271405dc664835e31595e3); ?>
<?php endif; ?><?php /**PATH C:\Users\MOTIUR RAHMAN\Desktop\rental.us\resources\views/frontEnd/welcome.blade.php ENDPATH**/ ?>