<aside class="app-sidebar sticky" id="sidebar">

    <!-- Start::main-sidebar-header -->
    <div class="main-sidebar-header">
        <a href="<?php echo e(route('dashboard')); ?>" class="header-logo">
            <img src="<?php echo e(asset($settings ? $settings->logo : '')); ?>" alt="logo">
        </a>
    </div>
    <!-- End::main-sidebar-header -->

    <!-- Start::main-sidebar -->
    <div class="main-sidebar" id="sidebar-scroll">

        <!-- Start::nav -->
        <nav class="main-menu-container nav nav-pills flex-column sub-open">
            <div class="slide-left" id="slide-left">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24"
                    viewBox="0 0 24 24">
                    <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path>
                </svg>
            </div>
            <ul class="main-menu">

                <!-- Dashboard -->
                <li class="slide">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="side-menu__item <?php echo e(Request::is('admin') ? 'active' : ''); ?>">
                        <i class="bx bxs-dashboard side-menu__icon"></i>
                        <span class="side-menu__label">Dashboard</span>
                    </a>
                </li>

                <!-- Category -->
                <li class="slide">
                    <a href="<?php echo e(route('admin.categories.index')); ?>"
                        class="side-menu__item <?php echo e(Request::is('admin/categories*') ? 'active' : ''); ?>">
                        <i class="bx bx-layer side-menu__icon"></i>
                        <span class="side-menu__label">Category</span>
                    </a>
                </li>

                <!-- Feature -->
                <li class="slide">
                    <a href="<?php echo e(route('admin.features.index')); ?>"
                        class="side-menu__item <?php echo e(Request::is('admin/features*') ? 'active' : ''); ?>">
                        <i class="bx bx-task side-menu__icon"></i>
                        <span class="side-menu__label">Feature</span>
                    </a>
                </li>

                <!-- Property -->
                <li class="slide">
                    <a href="<?php echo e(route('admin.properties.index')); ?>"
                        class="side-menu__item <?php echo e(Request::is('admin/properties*') ? 'active' : ''); ?>">
                        <i class="bx bx-home side-menu__icon"></i>
                        <span class="side-menu__label">Property</span>
                    </a>
                </li>

                <!-- Application -->
                <li class="slide">
                    <a href="<?php echo e(route('admin.application.index')); ?>"
                        class="side-menu__item <?php echo e(Request::is('admin/application*') ? 'active' : ''); ?>">
                        <i class="bx bx-file side-menu__icon"></i>
                        <span class="side-menu__label">Applications</span>
                    </a>
                </li>

                <li class="slide has-sub">
                    <a href="javascript:void(0);" class="side-menu__item">
                        <i class="bx bx-fingerprint side-menu__icon"></i>
                        <span class="side-menu__label">Authentication</span>
                        <i class="fe fe-chevron-right side-menu__angle"></i>
                    </a>
                    <ul class="slide-menu child1" data-popper-placement="bottom">
                        <li class="slide">
                            <a href="#" class="side-menu__item">Role & Permission</a>
                        </li>
                        <li class="slide">
                            <a href="#" class="side-menu__item">Users Manage</a>
                        </li>
                    </ul>
                </li>

                <!-- Settings -->
                <li class="slide">
                    <a href="<?php echo e(route('admin.setting.index')); ?>" class="side-menu__item <?php echo e(Request::is('admin/setting*') ? 'active' : ''); ?>">
                        <i class="bx bxs-cog side-menu__icon"></i>
                        <span class="side-menu__label">Settings</span>
                    </a>
                </li>

            </ul>
            <div class="slide-right" id="slide-right">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24"
                    viewBox="0 0 24 24">
                    <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path>
                </svg>
            </div>
        </nav>
        <!-- End::nav -->

    </div>
    <!-- End::main-sidebar -->

</aside>
<?php /**PATH C:\Users\MOTIUR RAHMAN\Desktop\rental.us\resources\views/backEnd/admin/includes/sidebar.blade.php ENDPATH**/ ?>