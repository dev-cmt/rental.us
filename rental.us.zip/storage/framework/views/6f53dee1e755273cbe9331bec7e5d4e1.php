<?php $__env->startSection('title', 'Mission Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
    <h1 class="page-title fw-semibold fs-18 mb-0">Mission Management</h1>
    <div class="ms-md-1 ms-0">
        <nav>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Mission</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-xl-12">
        <div class="card custom-card">
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php
                    $missionItems = [];
                    if (!empty($mission->mission_items)) {
                        $missionItems = is_array($mission->mission_items) ? $mission->mission_items : json_decode($mission->mission_items, true) ?? [];
                    }
                ?>

                <form action="<?php echo e(route('admin.mission.update', $mission->id)); ?>" method="POST" enctype="multipart/form-data" id="missionForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="form-label">Mission Image</label>
                            <input type="file" class="form-control" name="image_path">
                            <?php if($mission->image_path): ?>
                                <div class="mt-2">
                                    <img src="<?php echo e(asset($mission->image_path)); ?>" width="120" class="rounded border">
                                    <p class="small text-muted mb-0">Current Image</p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" required>
                                <option value="active" <?php echo e($mission->status == 'active' ? 'selected' : ''); ?>>Active</option>
                                <option value="inactive" <?php echo e($mission->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h5 class="mb-0">Mission Items</h5>
                        <button type="button" class="btn btn-sm btn-primary" id="addMissionItem">
                            <i class="ri-add-line me-1"></i> Add Item
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered align-middle" id="missionItemsTable">
                            <thead class="table-light">
                                <tr>
                                    <th style="width: 5%">#</th>
                                    <th style="width: 20%">Icon
                                        <a class="badge bg-success" href="https://dev-cmt.github.io/fontawesome.com" target="_blank">click</a>
                                    </th>
                                    <th style="width: 20%">Title</th>
                                    <th>Description</th>
                                    <th style="width: 10%">Order</th>
                                    <th style="width: 15%">Status</th>
                                    <th style="width: 5%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $missionItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="mission-item">
                                        <td><?php echo e($index+1); ?></td>
                                        <td>
                                            <input type="text" class="form-control" name="mission_items[<?php echo e($index); ?>][icon_class]" value="<?php echo e($item['icon_class'] ?? ''); ?>" required>
                                            <small class="text-muted">e.g. fa-solid fa-star</small>
                                        </td>
                                        <td><input type="text" class="form-control" name="mission_items[<?php echo e($index); ?>][title]" value="<?php echo e($item['title'] ?? ''); ?>" required></td>
                                        <td><textarea class="form-control" rows="1" name="mission_items[<?php echo e($index); ?>][description]" required><?php echo e($item['description'] ?? ''); ?></textarea></td>
                                        <td><input type="number" class="form-control" name="mission_items[<?php echo e($index); ?>][order]" value="<?php echo e($item['order'] ?? $index+1); ?>" required></td>
                                        <td>
                                            <select class="form-select" name="mission_items[<?php echo e($index); ?>][status]" required>
                                                <option value="active" <?php echo e($item['status'] == 'active' ? 'selected' : ''); ?>>Active</option>
                                                <option value="inactive" <?php echo e($item['status'] == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                            </select>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-danger remove-item">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="7" class="text-center">No mission items yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <button type="submit" class="btn btn-primary mt-3">Update Mission</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
$(document).ready(function() {
    let itemCount = <?php echo e(count($missionItems)); ?>;

    // Add new row
    $('#addMissionItem').click(function() {
        const index = itemCount++;
        const row = `
            <tr class="mission-item">
                <td>${index+1}</td>
                <td>
                    <input type="text" class="form-control" name="mission_items[${index}][icon_class]" value="fa-solid fa-" required>
                    <small class="text-muted">e.g. fa-solid fa-star</small>
                </td>
                <td><input type="text" class="form-control" name="mission_items[${index}][title]" required></td>
                <td><textarea class="form-control" rows="1" name="mission_items[${index}][description]" required></textarea></td>
                <td><input type="number" class="form-control" name="mission_items[${index}][order]" value="${index+1}" required></td>
                <td>
                    <select class="form-select" name="mission_items[${index}][status]" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </td>
                <td><button type="button" class="btn btn-sm btn-danger remove-item"><i class="ri-delete-bin-line"></i></button></td>
            </tr>`;
        $('#missionItemsTable tbody').append(row);
    });

    // Remove row
    $(document).on('click', '.remove-item', function() {
        if($('#missionItemsTable tbody .mission-item').length > 1){
            $(this).closest('tr').remove();
        } else {
            alert("You must keep at least one mission item.");
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backEnd.admin.layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\rental.us\resources\views/backEnd/admin/mission/index.blade.php ENDPATH**/ ?>